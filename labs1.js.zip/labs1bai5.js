var x = prompt("input n:");
document.write(x);
console.log(x);
alert(x);